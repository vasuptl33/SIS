<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../bootstrap/css/fontawesome.css">
<link rel="stylesheet" href="../bootstrap/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="../bootstrap/css/all.min.css">

<link rel="stylesheet" href="css/style.css">
