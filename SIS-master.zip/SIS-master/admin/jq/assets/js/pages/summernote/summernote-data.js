/**
 *  Document   : summernote-init.js
 *  Author     : redstar
 *  Description: script for set summernote properties
 *
 **/
$('#summernote').summernote({
        placeholder: '',
        tabsize: 2,
        height: 200
      });
$('#formsummernote').summernote({
    placeholder: '',
    tabsize: 2,
    height: 350
  });