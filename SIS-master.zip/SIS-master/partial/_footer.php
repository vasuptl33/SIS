
<style>
        #footer {
            clear: both;
    position: relative;
    height: 40px;
            background: #3f5485;
        }
    </style>

<footer id="footer">

</footer>